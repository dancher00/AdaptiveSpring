#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import JointState
from control_msgs.msg import JointControllerState
from std_msgs.msg import Float64
import numpy as np
import time
import pandas as pd
from controller_manager_msgs.srv import SwitchController
from std_srvs.srv import Empty


class Controller:
    def __init__(self) -> None:
        self.current_angles = np.array([0, 0])
        self.roll_pub = rospy.Publisher("/leg/joint_position_controller_4/command", Float64, queue_size=10)
        self.roll_pub.publish(Float64(0))

        # self.effort_publishers_position = [
        #     rospy.Publisher("/leg/joint_position_controller_6/command", Float64, queue_size=10),
        #     rospy.Publisher("/leg/joint_position_controller_8/command", Float64, queue_size=10),
        # ]
        self.knee_pub = rospy.Publisher("/leg/joint_position_controller_8/command", Float64, queue_size=10)

        rospy.wait_for_service('/gazebo/unpause_physics')
        unpause_physics = rospy.ServiceProxy('/gazebo/unpause_physics', Empty)
        _ = unpause_physics()
        time.sleep(1)

    def set_current_angles(self, angles):
        self.current_angles = angles

    def apply_effort(self, efforts):
        for pub, effort in zip(self.effort_publishers, efforts):
            pub.publish(Float64(effort))

    def apply_effort_position(self, efforts):
        for pub, effort in zip(self.effort_publishers_position, efforts):
            pub.publish(Float64(effort))



class RosManager:
    def __init__(self) -> None:
        rospy.init_node("listener", anonymous=True)
        self.controller = Controller()
        rospy.Subscriber("/leg/joint_states", JointState, self.listen_joint_state)
        rospy.Subscriber("/leg/joint_position_controller_8/state", JointControllerState, self.listen_controller_state)
        self.count = 0
        self.angle = 0
        self.position = 0
        self.angles = []
        self.positions = []
        self.torques = []

    def spin(self):
        rate = rospy.Rate(50)
        self.controller.knee_pub.publish(-0.6)
        position = -0.6
        down = False
        count = 0
        time.sleep(2)
        while not rospy.is_shutdown():
        # while(1):
            
            count+=1
            if position < -0.9:
                down = True
                self.angles.append('---')
                self.positions.append('---')
                self.torques.append('---')

            if position > -0.6:
                down = False
            
            if down:
                position += 0.03
            else:
                position -= 0.03

            self.controller.knee_pub.publish(position)

            if count == 200:
                data = {'Torque': self.torques, 'Angle': self.angles, 'Position': self.positions}
                df = pd.DataFrame(data)
                df.to_csv('With_spring_optimal.csv', index=False)
                print('Saved')

            # if rospy.is_shutdown():
            #     break

            rate.sleep()

        


    def listen_joint_state(self, msg: JointState):
        self.angle = msg.position[-2]
        self.position = msg.position[-1]
            

    def listen_controller_state(self, msg: JointControllerState):
        
        torque = msg.command
        # self.count+=1
        # if self.count % 2 == 0:
        self.torques.append(torque)
        self.angles.append(self.angle)
        self.positions.append(self.position)


if __name__ == "__main__":
    # rospy.wait_for_service('/leg/controller_manager/switch_controller')
    # switch_controller = rospy.ServiceProxy('/leg/controller_manager/switch_controller', SwitchController)
    # ret = switch_controller(start_controllers=['joint_effort_controller_6', 'joint_effort_controller_8'],
    #                         stop_controllers=['joint_position_controller_6', 'joint_position_controller_8'], strictness=1)
    ros_manager = RosManager()
    ros_manager.spin()

