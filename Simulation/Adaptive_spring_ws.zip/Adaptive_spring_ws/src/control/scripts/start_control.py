#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import JointState
from control_msgs.msg import JointControllerState
from std_msgs.msg import Float64
import numpy as np
import time
import pandas as pd
from controller_manager_msgs.srv import SwitchController
from std_srvs.srv import Empty


class Controller:
    def __init__(self) -> None:
        self.current_angles = np.array([0, 0])
        self.roll_pub = rospy.Publisher("/leg/joint_position_controller_4/command", Float64, queue_size=10)
        self.roll_pub.publish(Float64(0))

        self.knee_pub = rospy.Publisher("/leg/joint_position_controller_8/command", Float64, queue_size=10)
        self.hip_pub = rospy.Publisher("/leg/joint_position_controller_6/command", Float64, queue_size=10)

        rospy.wait_for_service('/gazebo/unpause_physics')
        unpause_physics = rospy.ServiceProxy('/gazebo/unpause_physics', Empty)
        _ = unpause_physics()
        time.sleep(1)

    def set_current_angles(self, angles):
        self.current_angles = angles


class RosManager:
    def __init__(self) -> None:
        rospy.init_node("listener", anonymous=True)
        self.controller = Controller()
        rospy.Subscriber("/leg/joint_states", JointState, self.listen_joint_state)
        rospy.Subscriber("/leg/joint_position_controller_8/state", JointControllerState, self.listen_controller_state)
        self.count = 0
        self.angle = 0
        self.position = 0
        self.angles = []
        self.positions = []
        self.torques = []

    def spin(self):
        rate = rospy.Rate(100)
        self.controller.hip_pub.publish(0)
        # self.controller.knee_pub.publish(-0.55)
        angle_knee = 0.05

        while angle_knee > -0.5:
            angle_knee -= 0.1
            # -0.22 with spring
            # angle_hip = -angle_knee / 2
            self.controller.knee_pub.publish(angle_knee)
            # self.controller.hip_pub.publish(angle_hip)
            time.sleep(0.2)

        h0 = -0.2
        t0 = 1
        a0 = 0.05
        t = 0
        T = 0.6
        l = 0.27
        count = 0

        time.sleep(2)
        while not rospy.is_shutdown():
        
            # self.angles.append('---')
            # self.positions.append('---')
            # self.torques.append('---')

            count+=1
            t+=0.01
            if t<t0:
                h = h0 + a0
            else:
                h = h0 - a0* np.sin((t- t0)/T - np.pi/2)
            angle_knee = 2 * np.arcsin(h/(2*l))
            angle_hip = angle_knee/2 + 0.3

            self.controller.knee_pub.publish(angle_knee)
            self.controller.hip_pub.publish(angle_hip)

            if count == 2000:
                data = {'Torque': self.torques, 'Angle': self.angles, 'Position': self.positions}
                df = pd.DataFrame(data)
                df.to_csv('Without_spring.csv', index=False)
                print('Saved')

            rate.sleep()

        


    def listen_joint_state(self, msg: JointState):
        self.angle = msg.position[-2]
        self.position = msg.position[-1]
            

    def listen_controller_state(self, msg: JointControllerState):
        
        torque = msg.command
        # self.count+=1
        # if self.count % 2 == 0:
        self.torques.append(torque)
        self.angles.append(self.angle)
        self.positions.append(self.position)


if __name__ == "__main__":
    # rospy.wait_for_service('/leg/controller_manager/switch_controller')
    # switch_controller = rospy.ServiceProxy('/leg/controller_manager/switch_controller', SwitchController)
    # ret = switch_controller(start_controllers=['joint_effort_controller_6', 'joint_effort_controller_8'],
    #                         stop_controllers=['joint_position_controller_6', 'joint_position_controller_8'], strictness=1)
    ros_manager = RosManager()
    ros_manager.spin()

